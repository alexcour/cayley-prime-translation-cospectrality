#!/usr/bin/env python3
"""Independent exact certificate for three-generator Cayley digraphs of U(210).

Python standard library only. Spectra are exact in Z[z]/(z^4-z^2+1).
Abstract types retain full relation tuples, never only a hash value.
Positive graph isomorphisms carry explicit vertex bijections; the three
negative cases are separated by a directly checked graph invariant.
"""
import argparse
import itertools
import json
from collections import Counter, defaultdict, deque
from pathlib import Path


MODS = (2, 4, 6)
ROOTS = ((1, 0, 0, 0), (0, 1, 0, 0), (0, 0, 1, 0), (0, 0, 0, 1),
         (-1, 0, 1, 0), (0, -1, 0, 1), (-1, 0, 0, 0), (0, -1, 0, 0),
         (0, 0, -1, 0), (0, 0, 0, -1), (1, 0, -1, 0), (0, 1, 0, -1))


class Group:
    def __init__(self):
        self.coords = list(itertools.product(*(range(m) for m in MODS)))
        self.index = {v: i for i, v in enumerate(self.coords)}
        self.residues = [71**a * 127**b * 31**c % 210 for a, b, c in self.coords]
        assert len(set(self.residues)) == 48
        self.residue_index = {v: i for i, v in enumerate(self.residues)}
        self.add = [[self.index[tuple((a + b) % m for a, b, m in zip(x, y, MODS))]
                     for y in self.coords] for x in self.coords]
        self.inverse = [self.index[tuple(-a % m for a, m in zip(x, MODS))]
                        for x in self.coords]
        self.characters = [[sum(a * b * (12 // m) for a, b, m in zip(c, x, MODS)) % 12
                            for x in self.coords] for c in self.coords]

    def spectrum(self, triple):
        return tuple(sorted(tuple(sum(ROOTS[row[t]][j] for t in triple) for j in range(4))
                            for row in self.characters))

    def subgroup(self, triple):
        found = {0}
        todo = deque([0])
        while todo:
            x = todo.popleft()
            for t in triple:
                y = self.add[x][t]
                if y not in found:
                    found.add(y)
                    todo.append(y)
        return sorted(found)

    def graph(self, triple):
        vertices = self.subgroup(triple)
        local = {x: i for i, x in enumerate(vertices)}
        return vertices, tuple(frozenset(local[self.add[x][t]] for t in triple)
                               for x in vertices)

    def powers(self, triple, horizon):
        rows = [Counter({0: 1})]
        for _ in range(horizon):
            row = Counter()
            for x, count in rows[-1].items():
                for t in triple:
                    row[self.add[x][t]] += count
            rows.append(row)
        return rows

    def characteristic_polynomial(self, triple):
        n = len(self.subgroup(triple))
        powers = self.powers(triple, n)
        traces = [n * row[0] for row in powers]
        coeffs = [1]
        for k in range(1, n + 1):
            num = -sum(coeffs[k - i] * traces[i] for i in range(1, k + 1))
            assert num % k == 0
            coeffs.append(num // k)
        return coeffs

    def return_profile(self, triple):
        walks = self.powers(triple, 3)[3]
        return sorted(walks[self.inverse[t]] for t in triple)

    def automorphisms(self):
        candidates = []
        for order in MODS:
            candidates.append([i for i, x in enumerate(self.coords)
                               if all(order * a % m == 0 for a, m in zip(x, MODS))])
        result = []
        for images in itertools.product(*candidates):
            mapping = []
            for ex in self.coords:
                y = tuple(sum(k * self.coords[im][j] for k, im in zip(ex, images)) % MODS[j]
                          for j in range(3))
                mapping.append(self.index[y])
            if len(set(mapping)) == 48:
                result.append(tuple(mapping))
        return result

    def abstract_type(self, triple):
        relations = []
        vectors = [self.coords[t] for t in triple]
        for coeffs in itertools.product(range(12), repeat=3):
            if all(sum(a * v[j] for a, v in zip(coeffs, vectors)) % MODS[j] == 0
                   for j in range(3)):
                relations.append(coeffs)
        # The full kernel of (Z/12)^3 -> <T>, canonical under reordering T.
        return min(tuple(sorted(tuple(row[j] for j in perm) for row in relations))
                   for perm in itertools.permutations(range(3)))


def verify_bijection(a, b, mapping):
    return (len(mapping) == len(a) == len(b) and len(set(mapping)) == len(a)
            and all({mapping[v] for v in a[u]} == set(b[mapping[u]]) for u in range(len(a))))


def rooted_isomorphism(a, b):
    """Complete joint color-refinement and backtracking for a rooted pair.

    Root 0 is sufficient because both input graphs are vertex-transitive.
    Returns an explicit checked bijection, or None after exhaustive search.
    """
    if len(a) != len(b):
        return None
    n = len(a)
    pa = tuple(frozenset(v for v in range(n) if u in a[v]) for u in range(n))
    pb = tuple(frozenset(v for v in range(n) if u in b[v]) for u in range(n))

    def refine(ca, cb):
        while True:
            sa = [(ca[u], tuple(sorted(ca[v] for v in a[u])), tuple(sorted(ca[v] for v in pa[u])))
                  for u in range(n)]
            sb = [(cb[u], tuple(sorted(cb[v] for v in b[u])), tuple(sorted(cb[v] for v in pb[u])))
                  for u in range(n)]
            labels = {s: i for i, s in enumerate(sorted(set(sa + sb)))}
            na, nb = tuple(labels[s] for s in sa), tuple(labels[s] for s in sb)
            if Counter(na) != Counter(nb):
                return None
            if len(set(na + nb)) == len(set(ca + cb)):
                return na, nb
            ca, cb = na, nb

    def search(ca, cb):
        refined = refine(ca, cb)
        if refined is None:
            return None
        ca, cb = refined
        classes = defaultdict(list)
        for u, color in enumerate(ca):
            classes[color].append(u)
        if len(classes) == n:
            reverse = {color: v for v, color in enumerate(cb)}
            mapping = tuple(reverse[color] for color in ca)
            return mapping if verify_bijection(a, b, mapping) else None
        color = min((c for c in classes if len(classes[c]) > 1),
                    key=lambda c: (len(classes[c]), c))
        u = classes[color][0]
        new_color = max(ca + cb) + 1
        for v in range(n):
            if cb[v] != color:
                continue
            na, nb = list(ca), list(cb)
            na[u] = nb[v] = new_color
            result = search(tuple(na), tuple(nb))
            if result is not None:
                return result
        return None

    initial = tuple(1 if u == 0 else 0 for u in range(n))
    return search(initial, initial)


def explicit_pairs(g):
    data = [('I', [31, 181, 169], [31, 61, 199]),
            ('II', [127, 157, 97], [157, 37, 67]),
            ('III', [127, 37, 43], [37, 67, 163])]
    result = []
    for label, aa, bb in data:
        a, b = tuple(g.residue_index[x] for x in aa), tuple(g.residue_index[x] for x in bb)
        sa, sb = g.subgroup(a), g.subgroup(b)
        ca, cb = g.characteristic_polynomial(a), g.characteristic_polynomial(b)
        ra, rb = g.return_profile(a), g.return_profile(b)
        assert sa == sb and ca == cb and g.spectrum(a) == g.spectrum(b)
        assert ra == [3, 4, 5] and rb == [3, 3, 6]
        # Independent check of the walk counts by explicit ordered triples.
        for t, profile in ((a, ra), (b, rb)):
            direct = sorted(sum(g.add[g.add[x][y]][z] == g.inverse[v]
                                for x, y, z in itertools.product(t, repeat=3)) for v in t)
            assert direct == profile
        result.append({'label': label, 'T': aa, 'T_prime': bb, 'subgroup_order': len(sa),
                       'same_actual_subgroup': True, 'characteristic_polynomial_coefficients': ca,
                       'spectrum_equal_exact': True, 'arc_return_3_profile_T': ra,
                       'arc_return_3_profile_T_prime': rb, 'nonisomorphism_certificate':
                       'different arc return profiles; invariant under any digraph isomorphism'})
    return result


def global_scan(g):
    triples = list(itertools.combinations(range(48), 3))
    spectra = defaultdict(list)
    for t in triples:
        spectra[g.spectrum(t)].append(t)
    print('Exact spectra:', len(spectra), flush=True)
    autos = g.automorphisms()
    pending = set(triples)
    orbits = {}
    while pending:
        rep = min(pending)
        family = {tuple(sorted(p[t] for t in rep)) for p in autos}
        assert family <= pending
        for t in family:
            orbits[t] = rep
        pending.difference_update(family)
    representatives = sorted(set(orbits.values()))
    print('Automorphism orbits:', len(representatives), flush=True)
    type_by_orbit = {t: g.abstract_type(t) for t in representatives}
    type_representative = {}
    for t in representatives:
        type_representative.setdefault(type_by_orbit[t], t)
    # All equal abstract types have equal spectra, checked without hash-only keys.
    spectrum_by_type = {}
    for t in representatives:
        ty, spec = type_by_orbit[t], g.spectrum(t)
        if ty in spectrum_by_type:
            assert spectrum_by_type[ty] == spec
        spectrum_by_type[ty] = spec
    by_spectrum = defaultdict(list)
    for ty, spec in spectrum_by_type.items():
        by_spectrum[spec].append(type_representative[ty])
    graph_count = 0
    collisions = []
    positive_certificates = []
    for spec, reps in by_spectrum.items():
        graph_reps = []
        for t in sorted(reps):
            st, at = g.graph(t)
            for u, su, au in graph_reps:
                if g.return_profile(t) != g.return_profile(u):
                    continue
                mapping = rooted_isomorphism(at, au)
                if mapping is not None:
                    assert verify_bijection(at, au, mapping)
                    positive_certificates.append({'T': [g.residues[x] for x in t],
                                                  'T_prime': [g.residues[x] for x in u],
                                                  'vertex_map': [[g.residues[st[x]], g.residues[su[y]]]
                                                                 for x, y in enumerate(mapping)]})
                    break
            else:
                graph_reps.append((t, st, at))
        graph_count += len(graph_reps)
        if len(graph_reps) > 1:
            profiles = [g.return_profile(t) for t, _, _ in graph_reps]
            assert len({tuple(x) for x in profiles}) == len(profiles)
            collisions.append({'fibre_size': len(spectra[spec]), 'types': len(reps),
                               'graph_types': len(graph_reps),
                               'representatives': [[g.residues[x] for x in t] for t, _, _ in graph_reps],
                               'subgroup_orders': [len(s) for _, s, _ in graph_reps],
                               'return_profiles': profiles})
    multi_type = sum(len(reps) > 1 for reps in by_spectrum.values())
    multi_orbit_types = Counter(type_by_orbit.values())
    augmented_observables = {(g.spectrum(t), tuple(g.return_profile(t)))
                             for t in type_representative.values()}
    assert len(augmented_observables) == graph_count == 213
    result = {'modulus': 210, 'group_factors': MODS, 'triples': len(triples),
              'automorphism_group_order': len(autos), 'automorphism_orbits': len(representatives),
              'abstract_types_exact': len(type_representative), 'digraph_types': graph_count,
              'spectral_classes': len(spectra), 'spectra_with_multiple_automorphism_orbits':
              sum(len({orbits[t] for t in family}) > 1 for family in spectra.values()),
              'spectra_with_multiple_abstract_types': multi_type,
              'abstract_types_in_multiple_automorphism_orbits': sum(n > 1 for n in multi_orbit_types.values()),
              'spectra_with_nonisomorphic_digraphs': len(collisions),
              'classes_of_augmented_observable_spectrum_and_return_3': len(augmented_observables),
              'collisions': collisions, 'positive_isomorphism_certificates': positive_certificates}
    assert (result['triples'], result['automorphism_orbits'], result['abstract_types_exact'],
            result['digraph_types'], result['spectral_classes']) == (17296, 318, 238, 213, 210)
    assert len(collisions) == 3 and multi_type == 28 and len(positive_certificates) == 25
    print('Classification:', (318, 238, graph_count, len(spectra)), flush=True)
    return result


def family_checks():
    """Finite checks of the accompanying uniform written proof.

    These checks are not used as a substitute for that proof.
    """
    roots6 = ((1, 0), (0, 1), (-1, 1), (-1, 0), (0, -1), (1, -1))
    def add(*vectors):
        return tuple(sum(v[k] for v in vectors) for k in range(2))
    ha = [add(*(roots6[j * r % 6] for r in (0, 1, 3))) for j in range(6)]
    hb = [add(*(roots6[j * r % 6] for r in (1, 2, 4))) for j in range(6)]
    assert hb[0] == ha[0]
    for j in range(1, 6):
        assert hb[j] == tuple(-x for x in ha[-j % 6])
    def profile(steps, length):
        counts = [1, 0, 0, 0, 0, 0]
        for _ in range(length):
            counts = [sum(counts[(r - s) % 6] for s in steps) for r in range(6)]
        return sorted(counts[-s % 6] for s in steps)
    rows = []
    for m in range(2, 82, 2):
        if m % 6 == 0:
            # Exact group automorphism F(u,v)=(u,v+u) mod (m,6).
            source = {(1, 0), (1, 1), (1, 3)}
            assert {(u, (v + u) % 6) for u, v in source} == {(1, 1), (1, 2), (1, 4)}
            rows.append({'m': m, 'isomorphic_by_explicit_group_automorphism': True})
            continue
        length = 3 if m == 2 else m - 1
        actual_a, actual_b = profile((0, 1, 3), length), profile((1, 2, 4), length)
        assert actual_a != actual_b
        if m % 6 == 4:
            q = (m - 4) // 6
            num = 3 ** (m - 1) - 3
            delta_num = 3 - (-1) ** q * 3 ** (m // 2)
            assert num % 6 == delta_num % 6 == 0
            c, delta = num // 6, delta_num // 6
            expected_a = sorted((c, c + 1, c + delta))
            expected_b = sorted((c + delta, c + delta, c + 1 - delta))
        elif m > 2:
            q = (m - 2) // 6
            p = (-1) ** q * 3 ** (m // 2)
            c, d, e = (3 ** (m - 1) + p) // 6, (3 ** (m - 1) - p) // 6, (3 ** (m - 1) - 3) // 6
            expected_a, expected_b = sorted((c, c, d)), sorted((c, e, e + 1))
        else:
            expected_a, expected_b = [3, 4, 5], [3, 3, 6]
        assert actual_a == expected_a and actual_b == expected_b
        rows.append({'m': m, 'return_path_length': length,
                     'profile_T': actual_a, 'profile_T_prime': actual_b,
                     'nonisomorphism_by_profile': True})
    return {'exact_sixth_root_identity_checked': True,
            'finite_instances': rows,
            'scope': 'uniform proof in PROOF_FAMILY.txt; 40 finite instances checked here'}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--pairs-only', action='store_true')
    parser.add_argument('--output', default='cayley_210_certificate_results.json')
    args = parser.parse_args()
    g = Group()
    result = {'method': 'exact integer and cyclotomic arithmetic, no floating point',
              'explicit_pairs': explicit_pairs(g),
              'family_checks': family_checks(),
              'scope': 'finite U(210) corpus; no general classification or novelty claim'}
    if not args.pairs_only:
        result['global_scan'] = global_scan(g)
    Path(args.output).write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
    print('All assertions passed. Results:', args.output, flush=True)


if __name__ == '__main__':
    main()
